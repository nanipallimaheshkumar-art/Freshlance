/**
 * Role-Based Access Control (RBAC) Module for FreshLane
 * 
 * Enforces strict access rules across Frontend routing and Backend API requests:
 * 
 * 1. Admin ('admin'): Master Key
 *    - Full access to storefront (/), admin dashboard (/admin), and delivery portal (/delivery)
 *    - Bypasses all backend restriction checks; can access any API endpoint
 * 
 * 2. Delivery Partner ('delivery_partner'): Restricted
 *    - ONLY allowed to access /delivery (and login screen)
 *    - Redirected immediately to /delivery if visiting /, /shop, or /admin
 *    - Can only call /api/delivery/* backend endpoints; blocked with 403 Forbidden for all other endpoints
 * 
 * 3. Customer ('customer'): Standard
 *    - Allowed to access public storefront (/, /shop, /checkout, /login)
 *    - Blocked and redirected to / with 'Access Denied' if visiting /admin or /delivery
 *    - Blocked with 403 Forbidden from any admin or delivery API endpoints
 */

export type AppRole = 'admin' | 'delivery_partner' | 'customer';

export interface SessionTokenPayload {
  userId: string;
  email: string;
  name: string;
  role: AppRole;
  iat?: number;
  exp?: number;
}

/**
 * Normalizes legacy or aliased roles to the 3 standard RBAC roles
 */
export function normalizeRole(role?: string | null): AppRole {
  if (!role) return 'customer';
  const clean = role.trim().toLowerCase();
  if (clean === 'admin' || clean === 'owner' || clean === 'administrator') {
    return 'admin';
  }
  if (clean === 'delivery_partner' || clean === 'driver' || clean === 'courier' || clean === 'delivery') {
    return 'delivery_partner';
  }
  return 'customer';
}

/**
 * Generate a Base64 session token that encodes role and user identity
 */
export function generateSessionToken(user: {
  id: string;
  email: string;
  name?: string;
  role: string;
}): string {
  const normRole = normalizeRole(user.role);
  const payload: SessionTokenPayload = {
    userId: user.id,
    email: user.email,
    name: user.name || user.email.split('@')[0],
    role: normRole,
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + 7 * 24 * 60 * 60, // 7 days
  };

  try {
    const json = JSON.stringify(payload);
    // Browser / Edge safe Base64 encoding
    if (typeof btoa !== 'undefined') {
      return btoa(unescape(encodeURIComponent(json)));
    }
    return Buffer.from(json, 'utf-8').toString('base64');
  } catch (e) {
    return `token_${normRole}_${user.id}`;
  }
}

/**
 * Decodes a session token from string or Base64
 */
export function parseSessionToken(tokenString?: string | null): SessionTokenPayload | null {
  if (!tokenString) return null;
  const raw = tokenString.replace(/^Bearer\s+/i, '').trim();
  if (!raw) return null;

  // Base64 decoding
  try {
    let json = '';
    if (typeof atob !== 'undefined') {
      json = decodeURIComponent(escape(atob(raw)));
    } else if (typeof Buffer !== 'undefined') {
      json = Buffer.from(raw, 'base64').toString('utf-8');
    }
    const parsed = JSON.parse(json);
    if (parsed && typeof parsed === 'object') {
      // Check expiration if exp field exists
      if (parsed.exp && typeof parsed.exp === 'number' && parsed.exp * 1000 < Date.now()) {
        return null;
      }
      return {
        userId: parsed.userId || 'usr_unknown',
        email: parsed.email || '',
        name: parsed.name || '',
        role: normalizeRole(parsed.role),
        iat: parsed.iat,
        exp: parsed.exp,
      };
    }
  } catch {
    return null;
  }

  return null;
}

export type AppRoute = 'storefront' | 'shop' | 'checkout' | 'admin' | 'delivery' | 'login';

/**
 * Normalizes a raw pathname or hash to an AppRoute
 */
export function parseCurrentRoute(pathname: string, hash: string, search?: string): AppRoute {
  const p = (pathname || '').toLowerCase();
  const h = (hash || '').toLowerCase();
  const s = (search || '').toLowerCase();

  // Query parameter overrides
  if (s.includes('web=delivery') || s.includes('app=delivery') || s.includes('portal=delivery')) {
    return 'delivery';
  }
  if (s.includes('web=admin') || s.includes('app=admin') || s.includes('portal=admin')) {
    return 'admin';
  }
  if (s.includes('web=customer') || s.includes('app=customer') || s.includes('portal=shop') || s.includes('portal=customer')) {
    return 'storefront';
  }

  // Delivery Portal routes
  if (
    p === '/delivery' ||
    p.startsWith('/delivery') ||
    p === '/delivery-portal' ||
    h === '#delivery' ||
    h === '#/delivery' ||
    h === '#delivery-portal' ||
    h === '#/delivery-portal'
  ) {
    return 'delivery';
  }

  // Admin Dashboard routes
  if (
    p === '/admin' ||
    p.startsWith('/admin') ||
    p === '/operations' ||
    h === '#admin' ||
    h === '#/admin' ||
    h === '#operations' ||
    h === '#ops'
  ) {
    return 'admin';
  }

  // Login route
  if (p === '/login' || h === '#login' || h === '#/login') {
    return 'login';
  }

  // Checkout and Payment routes
  if (
    p === '/checkout' ||
    p === '/payment' ||
    p.startsWith('/checkout') ||
    p.startsWith('/payment') ||
    h === '#checkout' ||
    h === '#/checkout' ||
    h === '#payment' ||
    h === '#/payment'
  ) {
    return 'checkout';
  }

  // Shop route
  if (p === '/shop' || h === '#shop' || h === '#/shop') {
    return 'shop';
  }

  // Default to storefront
  return 'storefront';
}

export interface RouteGuardEvaluation {
  allowed: boolean;
  redirectTo?: string;
  targetRoute: AppRoute;
  deniedReason?: string;
  notificationMessage?: string;
  requiresPortalLogin?: boolean;
}

/**
 * Evaluates frontend route access based on user role and authentication status
 * 
 * Rules:
 * 1. Admin (Master Key): Allowed on ALL routes (storefront, shop, checkout, admin, delivery, login).
 * 2. Delivery Partner (Restricted): ONLY allowed on 'delivery' (and 'login').
 *    Visiting storefront, shop, checkout, or admin redirects immediately to '/delivery'.
 * 3. Unauthenticated User: Can access customer storefront, shop, login.
 *    - Accessing '/checkout' or '/payment' is STRICTLY BLOCKED and redirected to '/login'
 *    - If accessing '/admin' or '/delivery', routed to dedicated Portal Login screen.
 * 4. Customer (Standard): Allowed on storefront, shop, checkout, login.
 *    - Blocked from '/admin' or '/delivery' with 'Access Denied'.
 */
export function evaluateRouteGuard(
  userRole: AppRole | null,
  route: AppRoute
): RouteGuardEvaluation {
  // 1. Admin: Master Key - accesses everything without restriction
  if (userRole === 'admin') {
    return {
      allowed: true,
      targetRoute: route,
    };
  }

  // 2. Delivery Partner: Allowed on /delivery and customer storefront for browsing
  if (userRole === 'delivery_partner') {
    if (route === 'admin') {
      return {
        allowed: false,
        redirectTo: '/delivery',
        targetRoute: 'delivery',
        deniedReason: 'Delivery partners cannot access the Admin Operations portal.',
        notificationMessage: 'Admin portal requires owner/administrator credentials.',
      };
    }
    return {
      allowed: true,
      targetRoute: route,
    };
  }

  // 3. Unauthenticated Guest: Can browse storefront and shop; checkout requires sign in
  if (userRole === null) {
    if (route === 'admin' || route === 'delivery') {
      return {
        allowed: true,
        targetRoute: route,
        requiresPortalLogin: true,
      };
    }
    if (route === 'checkout') {
      return {
        allowed: false,
        redirectTo: '/login',
        targetRoute: 'login',
        deniedReason: 'Please sign in or create an account to proceed to checkout.',
      };
    }
    return {
      allowed: true,
      targetRoute: route,
    };
  }

  // 4. Authenticated Customer: Blocked from Admin & Delivery portals
  if (route === 'admin' || route === 'delivery') {
    return {
      allowed: false,
      redirectTo: '/',
      targetRoute: 'storefront',
      deniedReason: 'Access Denied: You do not have permission to access this portal.',
      notificationMessage: 'Access Denied: You do not have permission to access this portal.',
    };
  }

  return {
    allowed: true,
    targetRoute: route,
  };
}

/**
 * API Authorization check for backend (Cloudflare Worker & Node server)
 * 
 * Rules:
 * 1. Admin: role === 'admin' bypasses all checks -> can access any endpoint.
 * 2. Delivery Partner: role === 'delivery_partner' can ONLY call /api/delivery/* endpoints.
 *    If calling customer or admin endpoint -> 403 Forbidden.
 * 3. Customer: role === 'customer' is blocked (403 Forbidden) from hitting any admin or delivery API endpoints.
 * 4. Order Creation / Checkout: STRICTLY requires valid authenticated session. Unauthenticated -> 401 Unauthorized.
 */
export function evaluateApiAccess(
  role: AppRole | null,
  pathname: string,
  method: string = 'GET'
): { allowed: boolean; status?: number; error?: string } {
  // 1. Admin: Master Key
  if (role === 'admin') {
    return { allowed: true };
  }

  const path = pathname.toLowerCase();
  const isAdminEndpoint = path.startsWith('/api/admin');
  const isDeliveryEndpoint =
    path.startsWith('/api/delivery') ||
    path.includes('/deliver') ||
    (path === '/api/orders' && method === 'GET') ||
    path === '/api/driver/location';

  const isOrderCreationEndpoint =
    (path === '/api/orders' || path === '/api/checkout' || path === '/api/create-order') &&
    method.toUpperCase() === 'POST';

  // 2. Unauthenticated requests on Order / Payment endpoints -> 401 Unauthorized
  if (!role && isOrderCreationEndpoint) {
    return {
      allowed: false,
      status: 401,
      error: '401 Unauthorized: Valid session token is required to create an order or proceed to payment.',
    };
  }

  // 3. Delivery Partner: ONLY /api/delivery/* allowed
  if (role === 'delivery_partner') {
    if (isDeliveryEndpoint) {
      return { allowed: true };
    }
    // Calling customer or admin endpoint
    return {
      allowed: false,
      status: 403,
      error: 'Forbidden: Delivery partners can only access /api/delivery/* endpoints.',
    };
  }

  // 4. Customer: Blocked from admin and delivery endpoints
  if (role === 'customer') {
    if (isAdminEndpoint || isDeliveryEndpoint) {
      return {
        allowed: false,
        status: 403,
        error: 'Forbidden: Customers cannot access admin or delivery endpoints.',
      };
    }
    return { allowed: true };
  }

  // Unauthenticated requests
  if (isAdminEndpoint) {
    return {
      allowed: false,
      status: 403,
      error: 'Forbidden: Administrator credentials required.',
    };
  }

  if (isDeliveryEndpoint && !path.includes('check-range')) {
    return {
      allowed: false,
      status: 403,
      error: 'Forbidden: Delivery partner credentials required.',
    };
  }

  return { allowed: true };
}
